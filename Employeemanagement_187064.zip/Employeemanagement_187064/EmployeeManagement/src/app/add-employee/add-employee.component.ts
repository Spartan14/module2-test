import { Component, OnInit } from '@angular/core';
//importing json file
import employeeData from '../Data/EmployeeDetails.json'
import{Router} from '@angular/router'
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
employee=employeeData;
//flag to validate the fields
flag=false;
flag1=false;
flag2=false;
flag3=false;
  constructor(private router:Router) { }

  ngOnInit() {
  }
//method for validate and adding employee in the json file
addEmployee(form)
{
  if(!form.id)
  {
this.flag=true
  }
   else if(!form.EmployeeName)
  {
    this.flag1=true
  }
   else if(!form.Email)
  {
    this.flag2=true
  }
 else if(!form.Phone)
  {
    this.flag3=true
  }
else
  {
  this.flag=false
  this.flag1=false
  this.flag2=false
  this.flag3=false
  this.employee.push(form);
  alert("Added succesfully");
  this.router.navigateByUrl("/list-all-employees")
}
}
}
