import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
//setting path for routing 
const routes: Routes = [
  {
    path:"list-all-employees",
    component:ListAllEmployeesComponent
  },
    {
      path:"add-employee",
      component: AddEmployeeComponent
    },
    {
      //default path for routing
      path:"",
      component:ListAllEmployeesComponent
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
