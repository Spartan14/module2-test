import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//import form module
import {FormsModule} from  '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';

@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    ListAllEmployeesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule // import form module
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
